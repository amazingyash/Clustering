#!/bin/sh

python3 data_form.py $1 $2 $3
python3 final.py $1 $4