
# coding: utf-8

# In[200]:


import sys
import time
import random
from multiprocessing import Lock, Pool
import numpy as np
import networkx as nx
import networkx.algorithms.isomorphism as iso
from networkx.algorithms import isomorphism
from sklearn.svm import LinearSVC
from sklearn.decomposition import PCA


# In[201]:


freq_subs = []
a_subs = []
i_subs = []
with open('a_out.txt', 'r') as r:
    for line in r:
        parts = line.split(' ')
        if(parts[0] == '#'):
            G = nx.Graph()
            a_subs.append(G)
        elif(parts[0] == 't'):
            continue
        elif(parts[0] == 'v'):
            a_subs[len(a_subs) - 1].add_node(int(parts[1]), label=int(parts[2]))
        elif(parts[0] == 'e'):
            a_subs[len(a_subs) - 1].add_edge(int(parts[1]), int(parts[2]), label=int(parts[3]))

with open('i_out.txt', 'r') as r:
    for line in r:
        parts = line.split(' ')
        if(parts[0] == '#'):
            G = nx.Graph()
            i_subs.append(G)
        elif(parts[0] == 't'):
            continue
        elif(parts[0] == 'v'):
            i_subs[len(i_subs) - 1].add_node(int(parts[1]), label=int(parts[2]))
        elif(parts[0] == 'e'):
            i_subs[len(i_subs) - 1].add_edge(int(parts[1]), int(parts[2]), label=int(parts[3]))

for i in a_subs:
    freq_subs.append(i)
fl = False
em = iso.categorical_edge_match('label', -1)
nm = iso.categorical_node_match('label', -1)
for i in i_subs:
    for j in freq_subs:
        GM = isomorphism.GraphMatcher(i, j, edge_match=em, node_match=nm)
        if GM.subgraph_is_isomorphic():
            fl = True
            break
    if fl == False:
        freq_subs.append(i)
        


# In[202]:


print('freq_subs len ', len(freq_subs))
for (u, v, l) in freq_subs[0].edges.data('label'):
    print(u, v, l)


# In[203]:


atom_map = {}
mols = {}
molid = []

with open(sys.argv[1], 'r') as r:
    labels = 0
    num_e = 0
    num_v = 0
    curr = -1
    lines = r.readlines()
    for i in range(len(lines)):
        if(lines[i][0] == '#'):
            curr = int(lines[i][1:])
            molid.append(curr)
            mols[curr] = nx.Graph()
            num_v = int(lines[i+1])
            for j in range(num_v):
                curn = lines[i+j+2][:len(lines[i+j+2]) - 1]
                if curn not in atom_map:
                    atom_map[curn] = labels
                    labels += 1
                mols[curr].add_node(j, label=atom_map[curn])
            num_e = int(lines[i+2+num_v])
            for j in range(num_e):
                parts = lines[i+3+num_v+j].split(' ')
                mols[curr].add_edge(int(parts[0]), int(parts[1]), label=int(parts[2]))
            i += num_e+num_v+3
    print(atom_map)


# In[204]:


reac = {}

with open('ca.txt', 'r') as r:
    for line in r:
        reac[int(line)] = 1
        
with open('ci.txt', 'r') as r:
    for line in r:
        reac[int(line)] = -1
        
print(len(reac))


# In[205]:


em = iso.categorical_edge_match('label', -1)
vm = iso.categorical_node_match('label', -1)
fv = {}

start = time.time()
for key, val in mols.items():
    if key not in reac:
        continue
    f_v = []
    for i in freq_subs:
        GM = isomorphism.GraphMatcher(val, i, edge_match=em, node_match=vm)
        if GM.subgraph_is_isomorphic():
            f_v.append(1)
        else:
            f_v.append(0)
    if reac[key] == 1:
        f_v.append(1)
    else:
        f_v.append(0)
    fv[key] = f_v
end = time.time()
print(end-start)
    
    


# In[214]:


count = 0
for key, val in fv.items():
    if val[-1] == 1:
        count += 1
print(count)
print(len(fv))

fff = open('train.txt', 'w')

for i in molid:
    if i not in fv:
        continue
    if fv[i][-1] == 1:
        fff.write('1')
    else:
        fff.write('-1')
    for j in range(len(freq_subs)):
        fff.write(' ' + str(j) + ':' + str(fv[i][j]))
    fff.write('\n')

fff.close()

test_mols = {}
test_id = []

with open(sys.argv[2], 'r') as r:
    labels = 0
    num_e = 0
    num_v = 0
    curr = -1
    lines = r.readlines()
    for i in range(len(lines)):
        if(lines[i][0] == '#'):
            curr = int(lines[i][1:])
            test_id.append(curr)
            test_mols[curr] = nx.Graph()
            num_v = int(lines[i+1])
            for j in range(num_v):
                curn = lines[i+j+2][:len(lines[i+j+2]) - 1]
                if curn not in atom_map:
                    atom_map[curn] = labels
                    labels += 1
                test_mols[curr].add_node(j, label=atom_map[curn])
            num_e = int(lines[i+2+num_v])
            for j in range(num_e):
                parts = lines[i+3+num_v+j].split(' ')
                test_mols[curr].add_edge(int(parts[0]), int(parts[1]), label=int(parts[2]))
            i += num_e+num_v+3

test_fv = {}

for key, val in test_fv.items():
    f_v = []
    for i in freq_subs:
        GM = isomorphism.GraphMatcher(val, i, edge_match=em, node_match=vm)
        if GM.subgraph_is_isomorphic():
            f_v.append(1)
        else:
            f_v.append(0)
    test_fv[key] = f_v

fff = open('test.txt', 'w')
for i in test_id:
    for j in range(len(freq_subs)):
        fff.write(' ' + str(j) + ':' + test_fv[i][j])
    print('\n')

fff.close()



# # In[223]:


# X = []
# Y = []

# keys = list(fv.keys())
# random.shuffle(keys)
# for key in keys:
#     if count == 0 and fv[key][-1] == 0:
#         continue
#     if fv[key][-1] == 0:
#         count -= 1
#     X.append(fv[key][:-1])
#     Y.append(fv[key][-1])
# X = np.array(X)
# Y = np.array(Y)


# # In[224]:


# print(X.shape)
# clf = LinearSVC()
# clf.fit(X, Y)


# # In[225]:


# testX = []
# testY = []
# keys = list(fv.keys())
# random.shuffle(keys)
# for key in keys:
#     if(count == 252 and fv[key][-1] == 0):
#         continue
#     if(fv[key][-1] == 0):
#         count += 1
#     testX.append(fv[key][:-1])
#     testY.append(fv[key][-1])
# testX = np.array(testX)
# testY = np.array(testY)


# # In[226]:


# print(X.shape)
# print('training accuracy', clf.score(X, Y))
# print('test accuracy', clf.score(testX, testY))


# # In[227]:


# select = []
# coeffs = clf.coef_
# print(coeffs)
# print(coeffs.shape)
# for i in range(len(coeffs[0])):
#     if abs(coeffs[0][i]) < 0.4:
#         select.append(i)
# print(select)


# # In[228]:


# # X = np.delete(X, select, axis=1)
# # clf.fit(X, Y)
# # testX = np.delete(testX, select, axis=1)
# # print 'training accuracy', clf.score(X, Y)
# # print 'test accuracy', clf.score(testX, testY)


# # In[229]:

# print('PCA')


# n_c = int(len(freq_subs)*0.3)
# pca = PCA(n_components=n_c)
# pca.fit(X)
# X = pca.transform(X)
# testX = pca.transform(testX)
# clf.fit(X, Y)
# print('training accuracy', clf.score(X, Y))
# print('test accuracy', clf.score(testX, testY))

