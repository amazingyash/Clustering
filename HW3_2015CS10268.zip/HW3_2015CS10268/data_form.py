import sys
import os

atom_map = {}
molc = 0
labels = 0
num_e = 0
num_v = 0

reac = {}

with open(sys.argv[2], 'r') as r:
	for i in r:
		reac[int(i)] = 1

with open(sys.argv[3], 'r') as r:
	for i in r:
		reac[int(i)] = -1

fw = open('data.txt', 'w')
fa = open('a_mols.txt', 'w')
fi = open('i_mols.txt', 'w')
a_c = 0
i_c = 0
a_f = False
i_f = False
with open(sys.argv[1], 'r') as r:
	lines = r.readlines()
	for i in range(len(lines)):
		if(lines[i][0] == '#'):
			fw.write("t # " + str(molc) + "\n")
			mid = int(lines[i][1:])
			if mid not in reac:
				a_f = False
				i_f = False
			elif reac[mid] == 1:
				a_f = True
				a_c += 1
			elif reac[mid] == -1:
				i_f = True
				i_c += 1
			if a_f:
				fa.write("t # " + str(a_c-1) + "\n")
			if i_f:
				fi.write("t # " + str(i_c-1) + "\n")
			molc += 1
			num_v = int(lines[i+1])
			for j in range(num_v):
				curr = lines[i+j+2][:len(lines[i+j+2]) - 1]
				if curr not in atom_map:
					atom_map[curr] = labels
					labels += 1
				fw.write("v " + str(j) + " " + str(atom_map[curr]) + "\n")
				if a_f:
					fa.write("v " + str(j) + " " + str(atom_map[curr]) + "\n")
				if i_f:
					fi.write("v " + str(j) + " " + str(atom_map[curr]) + "\n")
			num_e = int(lines[i+2+num_v])
			# print num_e
			for j in range(num_e):
				fw.write("e " + lines[i+3+num_v+j])
				if a_f:
					fa.write("e " + lines[i+3+num_v+j])
				if i_f:
					fi.write("e " + lines[i+3+num_v+j])
			i += num_e+num_v+3
	# print atom_map
	fw.close()

fa.close()
fi.close()
command1 = './gaston-1.1/gaston ' + str(int(a_c/2)) + ' a_mols.txt ' + 'a_out.txt'
command2 = './gaston-1.1/gaston ' + str(int(i_c*0.33)) + ' i_mols.txt ' + 'i_out.txt'
os.system(command1)
os.system(command2)







