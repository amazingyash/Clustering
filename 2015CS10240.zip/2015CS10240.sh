#!/bin/sh
# Run this in terminal
if [ $1 = "-kmeans" ]
then
	./kmeans $2 $3
elif [ $1 = "-dbscan" ] 
then
	./db $2 $3 $4
elif [ $1 = "-optics" ] 
then
	./optics $2 $3 $4
	python reach_plot.py
else
	echo "sh <rollno>.sh -kmeans <k>  <filename>"
	echo "sh <rollno>.sh -dbscan <minPts> <epsilon> <filename>"
	echo "sh <rollno>.sh -optics <minPts> <epsilon> <filename>"
fi
exit 0
