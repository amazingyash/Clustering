#include <bits/stdc++.h>

using namespace std;

int minPts;
float eps;
float **data;
vector<float> core_dist;
vector<float> reach_dist;
vector<bool> processed;
int idx;
int dim = 0;
int data_len = 0;

template <class T, class Container = std::vector<T>,
          class Compare = std::less<T> >
class my_priority_queue {
protected:
    Container c;
    Compare comp;
public:
    explicit my_priority_queue(const Container& c_  = Container(),
                            const Compare& comp_ = Compare())
        : c(c_), comp(comp_)
    {
        std::make_heap(c.begin(), c.end(), comp);
    }
    bool empty()       const { return c.empty(); }
    std::size_t size() const { return c.size(); }
    const T& top()     const { return c.front(); }
    void push(const T& x)
    {
        c.push_back(x);
        std::push_heap(c.begin(), c.end(), comp);
    }
    void pop()
    {
        std::pop_heap(c.begin(), c.end(), comp);
        c.pop_back();
    }
    void remove(const T& x)
    {
        auto it = std::find(c.begin(), c.end(), x);
        if (it != c.end()) {
            c.erase(it);
            std::make_heap(c.begin(), c.end(), comp);
        }
    }
};

float dist(int a, int b)
{
	float res = 0;
	for(int i = 0 ; i < dim ; i++)
	{
		res += pow(data[a][i] - data[b][i], 2);
	}
	res = sqrt(res);
	return res;
}

vector<int> get_neighbours(int a)
{
	vector<int> res;
	for(int i = 0 ; i < data_len ; i++)
	{
		if(i == a)
			continue;
		if(dist(a, i) <= eps)
			res.push_back(i);
	}
	return res;
}

// check to see if this works

class myComp
{
public:
	bool operator()(const int &a, const int &b)
	{
		return dist(a, idx) > dist(b, idx);
	}
};

class myComp2
{
public:
	bool operator()(const int &a, const int &b)
	{
		return reach_dist[a] > reach_dist[b];
	}
};

float get_core_distance(int a, vector<int> &neighbours)
{
	if(neighbours.size() < minPts)
		return INT_MAX;
	idx = a;
	priority_queue<int, vector<int>, myComp> pq;
	for(int i = 0 ; i < neighbours.size() ; i++)
	{
		pq.push(i);
	}
	int last = 0;
	for(int i = 0 ; i < minPts ; i++)
	{
		last = pq.top();
		pq.pop();
	}
	return dist(last, a);
}

void read_data(const char *file_name)
{
	ifstream infile;
	infile.open(file_name);

	string line;

	getline(infile, line);
	data_len++;
	stringstream ss;
	ss.str(line);

	float val;

	while(ss >> val)
	{
		dim++;
	}

	while(getline(infile, line))
	{
		data_len++;
	}

	infile.close();
	infile.open(file_name);

	data = (float **)malloc(sizeof(float *) * data_len);
	for(int i = 0 ; i < data_len ; i++)
	{
		data[i] = (float *)malloc(sizeof(float) * dim);
	}
	int i = 0, j = 0;
	while(infile)
	{
		getline(infile, line);
		stringstream sss(line);
		j = 0;
		while(sss >> val)
		{
			data[i][j] = val;
			j++;
		}
		i++;
	}

	infile.close();
}

void update(vector<int> &neigh, int pt, my_priority_queue<int, vector<int>, myComp2> &pq)
{
	float new_reach_dist;
	for(auto a : neigh)
	{
		if(processed[a])
			continue;
		new_reach_dist = max(core_dist[pt], dist(a, pt));
		//cout<<"lassan "<<pt<<" "<<new_reach_dist<<" "<<core_dist[pt]<<" "<<a<<endl;
		if(reach_dist[a] == INT_MAX)
		{
			reach_dist[a] = new_reach_dist;
			pq.push(a);
		}
		else
		{
			if(new_reach_dist < reach_dist[a])
			{
				reach_dist[a] = new_reach_dist;
				pq.remove(a);
				pq.push(a);
			}
		}
	}
}

void cluster(vector<int> &order)
{
	order.reserve(data_len);
	vector<int> neigh;
	vector<int> neigh2;
	my_priority_queue<int, vector<int>, myComp2> seeds;
	int q;

	for(int i = 0 ; i < data_len ; i++)
	{
		if(processed[i])
			continue;
		neigh = get_neighbours(i);
		core_dist[i] = get_core_distance(i, neigh);

		order.push_back(i);
		processed[i] = true;

		if(core_dist[i] != INT_MAX)
		{
			reach_dist[i] = core_dist[i];
			update(neigh, i, seeds);
			while(!seeds.empty())
			{
				q = seeds.top();
				seeds.pop();
				neigh2 = get_neighbours(q);
				processed[q] = true;
				order.push_back(q);
				core_dist[q] = get_core_distance(q, neigh2);
				if(core_dist[q] != INT_MAX)
				{
					update(neigh2, q, seeds);
				}
			}
		}
	}
}

int main(int argc, char const *argv[])
{
	if(argc < 4)
	{
		cout<<"Invalid arguments"<<endl;
		return -1;
	}

	minPts = atoi(argv[1]);
	eps = atof(argv[2]);

	read_data(argv[3]);
	cout<<data_len<<"x"<<dim<<endl;
	cout<<data[3][0]<<" "<<data[3][1]<<endl;

	core_dist.resize(data_len, INT_MAX);
	reach_dist.resize(data_len, INT_MAX);
	processed.resize(data_len, false);

	vector<int> ord;

	cluster(ord);

	ofstream outfile;
	outfile.open("out.txt");
	for(auto la : ord)
	{
		if(reach_dist[la] != INT_MAX)
		outfile<<la<<" "<<reach_dist[la]<<endl;
		else
			outfile<<la<<" "<<0<<endl;
	}
	outfile.close();

	return 0;
}
