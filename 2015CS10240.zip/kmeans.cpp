#include <bits/stdc++.h>
using namespace std;

float minnn;
float max_dist;
int rand();

float dist(vector<float>&pt1, vector<float>&pt2){
	int d = pt1.size();
	float sum = 0;
	for(int i = 0; i < d; i++){
		sum += (pt1[i]-pt2[i])*(pt1[i]-pt2[i]);
	}
	return sqrt(sum);
}

void my_file_read(vector<vector<float>> &data, string inp){
	
	ifstream file;
	string str;
	file.open(inp);
	while(getline(file, str)){
		stringstream ss(str);
	    float n;
	    vector<float> d;
	    while(ss >> n){
	    	d.emplace_back(n);
	    }
	    // labels.push_back(d.back());
	    // d.pop_back();
	    data.emplace_back(d);
    }
	file.close();

	// for(int i=0;i<data.size();i++)
	// {
	// 	for(int j=0;j<data[i].size();j++)
	// 	{
	// 		cout<<data[i][j]<<" ";
	// 	}
	// 	cout<<endl;
	// }
	// return labels;
}

inline float distt(vector<float> a, vector<float> b)
{
	float ans;
	for(int i=0;i<a.size();i++)
	{
		ans += (a[i] - b[i])*(a[i] - b[i]);
	}

	return (ans);
}

vector<int> kmeans(vector<vector<float>> &data,int k){

	int dim = data[0].size();

	vector<int> labels(data.size(),-1);
	vector< vector<float> > centres(k);
	// vector<int> indices;
	int c=0;

	// for(int i=0;i<data.size();i++)
	// {
	// 	indices.push_back(c);
	// 	c++;
	// }


	// random_device rd;
	// mt19937 rng(rd());
	// shuffle(indices.begin(), indices.end(), rng);
	srand ( time(NULL) );
	for(int i=0;i<k;i++)
	{
		centres[i] = data[rand()%data.size()];
	}

	// Sanity check
	assert(data.size() >= k);

	// for (int idx = 0; idx < k; ++idx) {
	// 	// cout<<"+ "<<indices[idx]<<endl;
	// 	centres[idx] = data[indices[idx]];
	// 	// cout<<centres[idx][0]<<" "<<centres[idx][1]<<endl;
	// }

	// centres[0][0] = 10; centres[0][1] = 6;
	// centres[1][0] = 10; centres[1][1] = 14;

	int flag = 0;
	int epoch = 10000;
	while(flag == 0 || epoch == 0)
	{
		epoch--;
		// cout<<"-------------------------------------------------------------------------------------------------"<<endl;
		// for(int i=0;i<k;i++)
		// {
		// 	cout<<"Centre "<<i<<" ( ";
		// 	for(int j=0;j<dim;j++)
		// 		cout<<centres[i][j]<<" ";
		// 	cout<<endl;
		// }
		max_dist = -1;

		for(int i=0;i<data.size();i++)
		{
			minnn = FLT_MAX;
			int min_j = -1;
			for(int j=0;j<k;j++)
			{
				// cout<<"idhar "<<minnn<<" "<<j<<endl;
				float temp = distt(data[i],centres[j]);
				// cout<<"Distance from "<<j<<" is "<<temp<<endl;
				if(temp < minnn)
				{

					// cout<<"Distance if point from "<<j<<" is less than that from "<<min_j<<endl;
					minnn = temp;
					// cout<<minnn<<endl;
					min_j = j;
				}

			}
			// cout<<"Chose "<<min_j<<endl;
			labels[i] = min_j;

			// if(labels[i] == 0)
			// 	cout<<"labels[i]"<<endl;
		}



		for(int i=0;i<k;i++)
		{
			vector<float> temp(dim,0.0);
			int count = 0;
			for(int j=0;j<data.size();j++)
			{
				if(labels[j] == i)
				{
					count++;
					for(int p=0;p<dim;p++)
						temp[p] += data[j][p];
				}
			}

			if(count == 0)
				centres[i] = data[rand()%data.size()];

			// float tempp= 0.0;
			for(int p=0;p<dim;p++)
			{	
				// tempp += pow((centres[i][k] - temp[k]),2);
				temp[p] = temp[p]/count;
				// cout<<centres[i][p]<<" ";
			}

			float fg = distt(centres[i],temp);


			centres[i] = temp;

			if(fg > max_dist)
				{max_dist = fg;}
			// cout<<endl;
			// cout<<tempp<<endl;
			// e+= (tempp);
		}

		// cout<<max_dist<<endl;
		if(max_dist < 0.001)
			flag = 1;
		// cout<<endl;
		// cout<<e<<endl;
		// e = sqrt(e/k);
		
		// if(e < 1)
			// flag = 1;
	}

	// for(int i=0;i<k;i++)
	// 	{data.push_back(centres[i]);
	// 	labels.push_back(10);}

	return labels;

}

int main(int argc, char* args[]){

	string inp;
	int k = atoi(args[1]);
	inp = args[2]; 
	vector<vector<float>> data;
	clock_t tStart = clock();
	
	my_file_read(data, inp);
	vector<int> result = kmeans(data,k);

	ofstream myfile;
    myfile.open ("kmeans.txt");
    
	// for(int i=0;i<result.size();i++)
	// {
	// 	for(int j=0;j<data[i].size();j++)
	// 		myfile<<data[i][j]<<" ";
	// 	myfile<<result[i]<<endl;

	// 	// myfile<<data[i][2]<<" "<<data[i][4]<<endl;	
	// }



	for(int i=0;i<k;i++)
	{
		myfile<<"#"<<i<<endl;
		for(int j=0;j<data.size();j++)
		{
			if(result[j] == i)
			{
				// for(int p=0;p<data[j].size();p++)
					// myfile<<data[j][p]<<" ";
				myfile<<j<<endl;
			}
			
		}
	}

	myfile.close();
 //    myfile.open ("plot.txt");
 //    for(int i=0;i<k;i++)
	// {
	// 	// myfile<<"#"<<i<<endl;
	// 	for(int j=0;j<data.size();j++)
	// 	{
	// 		if(result[j] == i)
	// 		{
	// 			for(int p=0;p<data[j].size();p++)
	// 				myfile<<data[j][p]<<" ";
	// 			myfile<<i<<endl;
	// 		}
			
	// 	}
	// }
	// myfile.close();
	cout<<"Time taken: "<<((double)(clock() - tStart)/CLOCKS_PER_SEC)<<endl;
}