#include <bits/stdc++.h>
using namespace std;
#include "kdtree.h"


float dist(vector<float>&pt1, vector<float>&pt2){
	int d = pt1.size();
	float sum = 0;
	for(int i = 0; i < d; i++){
		sum += (pt1[i]-pt2[i])*(pt1[i]-pt2[i]);
	}
	return sqrt(sum);
}

list<int> RangeQuery(vector<vector<float>> &data, int pt, float eps){
	list<int> Neighbors;
	int npts = data.size();
	for(int i = 0; i < npts; i++){
		if(pt != i && dist(data[i], data[pt]) < eps){
			Neighbors.push_back(i);
		}
	}
	return Neighbors;
}




list<int> RangeQuery_bin(vector<vector<float>> &data, int pt, float eps){
	list<int> Neighbors;
	int npts = data.size();
	int s = -1;
	int e = -1;

	float val = data[pt][0];
	int l = 0; 
	int h = pt-1;
	int mid;

	float s1 = val - eps;


	//////////////// In the left part search //////////////////
	while(l <= h){
		mid = (l+h)/2;
		if(mid >= 1.0 && data[mid-1][0] < s1 && data[mid][0] >= s1){
			s = mid;
			break;
		}
		else if(mid < 1.0 && data[mid][0] >= s1){
			s = mid;
			break;
		}
		if(data[mid][0] > s1)
			h = mid-1;
		else if(data[mid][0] < s1)
			l = mid+1;
	}
	if(s == -1)
		s = pt+1;

	//////////////// In the left part search //////////////////

	//////////////// In the right part search //////////////////
	l = pt+1; 
	h = npts-1;
	mid;

	s1 = val + eps;

	while(l <= h){
		mid = (l+h)/2;
		if(mid < npts-1 && data[mid+1][0] > s1 && data[mid][0] <= s1){
			e = mid;
			break;
		}
		else if(mid >= npts-1 && data[mid][0] <= s1){
			e = mid;
			break;
		}
		if(data[mid][0] < s1)
			l = mid+1;
		else if(data[mid][0] > s1)
			h = mid-1;
	}
	if(e == -1)
		e = pt-1;
	//////////////// In the right part search //////////////////

	// if( s != pt+1)
	// 	cout<<(val-eps)<<" "<<data[s][0]<<" "<<s1<<" "<<data[e][0];

	for(int i = s; i <= e; i++){
		if(pt != i){
			Neighbors.push_back(i);
		}
	}
	return Neighbors;
}



list<int> RangeQuery_kd(vector<vector<float>> &data, int pt, float eps, kdtree* ptree){

	int dim = data[0].size();
	float* query = new float[dim];
	for(int j=0;j<dim;j++)
		query[j] = data[pt][j];

	struct kdres *presults = kd_nearest_rangef( ptree, query, eps );

	list<int> N;
	float* pos;
	while( !kd_res_end( presults ) ) {
	    void* t = ((char*)kd_res_itemf( presults, pos ));
	    int pch = (int)((long)t);
	    N.push_back(pch);
	    kd_res_next( presults );
  	}

  	//cout<<"YE le "<<N.size()<<endl<<endl<<endl;

  	kd_res_free( presults );
  	return N;

}




void dbscan(vector<vector<float>> &data, int minpts, float eps){

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	int dim = data[0].size();
	kdtree* ptree;
	// cout<<dim<<" "<<endl;
	if(dim != 1){
		ptree = kd_create( dim );
		// cout<<"dim:"<<dim<<endl;
		for(int i=0;i<data.size();i++)
		{
			float* insert = new float[dim];
			for(int j=0;j<dim;j++)
				insert[j] = data[i][j];

			kd_insertf( ptree, insert ,(void*)((long)i));
		}
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	int c = -1;

	int npts = data.size();
	vector<int> label(npts, -2);			// -2 represents undefined 
	for(int i = 0; i < npts; i++){
		
		if(label[i] != -2)
			continue;

		list<int> N;
		if(dim == 1)
			N = RangeQuery_bin(data, i, eps);		
		else N = RangeQuery_kd(data, i, eps, ptree);		
		if(int(N.size()) < minpts){
			label[i] = -1;
			continue;
		}
		
		c += 1;
		label[i] = c;
		list<int> seed = N;
		list<int>::iterator iter = seed.begin();
		while(!seed.empty()){
			int Q = *iter;
			iter++;
			seed.pop_front();
			
			if(label[Q] == -1)
				label[Q] = c;
			if(label[Q] != -2)
				continue;
			label[Q] = c;
		
			list<int> newpts;
			if(dim == 1)
				newpts = RangeQuery_bin(data, Q, eps);		
			else newpts = RangeQuery_kd(data, Q, eps, ptree);		
			if(int(newpts.size()) >= minpts){
				seed.splice(seed.end(), newpts);
			}
		}
	}

	if(dim != 1)
		kd_free( ptree );


	 int count = 0;
	 // unordered_map<int, > m;
	 // for(int i = 0; i < npts; i++){
	 // 	cout<<label[i]<<endl;
	 	// if(label[i] != data[i][2])
	 	// 	count++;
	 // }
	 // cout<<(count*1.0)/data.size()<<endl;
	 // cout<<count<<endl;


	ofstream myfile;
	count = 0;
    myfile.open ("dbscan.txt");
	for(int i = -1;i <= c;i++){
		if(i == -1)
			myfile<<"#outlier"<<endl;	
		else myfile<<"#"<<i<<endl;
		for(int j=0;j<data.size();j++)
		{
			if(label[j] == i)
			{
				// count++;
				myfile<<j<<" ";
				myfile<<endl;
			}
			
		}
	}

	// cout<<"writtem:"<<count<<endl;

}


void my_file_read(vector<vector<float>> &data, string inp){
	
	ifstream file;
	string str;
	file.open(inp);
	while(getline(file, str)){
		stringstream ss(str);
	    float n;
	    vector<float> d;
	    while(ss >> n){
	    	d.emplace_back(n);
	    }
	    data.emplace_back(d);
    }
    if(data[0].size() == 1){
    	// cout<<"SORTED"<<endl;
		sort(data.begin(), data.end(), [](vector<float> a, vector<float> b){
			return (a[0] < b[0]);
		});
    }
	file.close();
}

int main(int argc, char* args[]){
	string inp;
	inp = args[3]; 
	vector<vector<float>> data;

	clock_t tStart = clock();
	
	my_file_read(data, inp);
	int minpts = atoi(args[1]);
	float eps = atof(args[2]);
	dbscan(data, minpts, eps);

	// cout<<"Time taken: "<<((double)(clock() - tStart)/CLOCKS_PER_SEC)<<endl;
}
