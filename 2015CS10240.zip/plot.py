import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

def plot():
	with open("plot.txt") as f:
		content = f.readlines()

	content = [a.strip('\n') for a in content]
	content = [a.strip(' ') for a in content]
	content = [a.split(" ") for a in content]
	content = [[float(i) for i in a] for a in content]

	x = []
	y = []
	c = []


	for l in content:
		x.append(l[0])
		y.append(l[1])
		c.append((int)(l[2]))


	plt.scatter(x,y,c=c)
	plt.show()

def kmeans():
	with open("plot.txt") as f:
		content = f.readlines()

	content = [a.strip('\n') for a in content]
	content = [a.strip(' ') for a in content]
	content = [a.split(" ") for a in content]
	content = [[float(i) for i in a] for a in content]

	x = []
	y = []
	c = []

	for l in content:
		x.append(l[0])
		y.append(l[1])
		c.append(l[2])

	data = []
	for i in range(len(x)):
		data.append([x[i],y[i]])

	data = np.array(data)

	kmeans = KMeans(n_clusters=7, random_state=1)
	aaa = kmeans.fit_predict(data)
	plot(aaa)

plot()
