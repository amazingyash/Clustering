#!/bin/sh
# Run this in terminal
g++ -O3 -o kmeans kmeans.cpp -std=c++11
gcc -O3 -c kdtree.h kdtree.c
g++ -O3 -c dbscan.cpp -std=c++11
g++ -O3 -o db kdtree.o dbscan.o
g++ -O3 -o optics optics.cpp -std=c++11

exit 0
