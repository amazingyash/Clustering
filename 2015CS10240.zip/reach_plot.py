import sys
import matplotlib.pyplot as plt

reach = []
order = []

with open('out.txt', 'r') as a:
	for line in a:
		toks = line.split(' ')
		order.append(int(toks[0]))
		reach.append(float(toks[1]))

plt.plot(reach)
plt.title('Reachability Plot')
plt.ylabel('Reachability')
plt.xlabel('Points in order of processing')
plt.savefig('reachability_plot.png')
plt.show()
